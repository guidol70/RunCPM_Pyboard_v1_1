#ifndef STM32_H
#define STM32_H

// SPI_DRIVER_SELECT must be set to 2 in SdFat/SdFatConfig.h (default is 0)

SdFat32 SD;
typedef File32 File;

const uint8_t SD_CS_PIN     = 43; // PC11 - MicroSD-Pin 2
const uint8_t SOFT_MISO_PIN = 40; // PC8  - MicroSD-Pin 7
const uint8_t SOFT_MOSI_PIN = 48; // PD2  - MicroSD-Pin 3
const uint8_t SOFT_SCK_PIN  = 44; // PC12 - MicroSD-Pin 5

SoftSpiDriver<SOFT_MISO_PIN, SOFT_MOSI_PIN, SOFT_SCK_PIN> softSpi;

#define SDMHZ 50
// #define SDMHZ_TXT "50"

#define SDINIT SdSpiConfig(SD_CS_PIN, DEDICATED_SPI, SD_SCK_MHZ(SDMHZ), &softSpi)

// HDD-LED definitin for my Pyboard v1.1 Clone
#define LED 13  // Green  LED
// #define LED 14  // Red    LED
// #define LED 15  // Yellow LED
// #define LED 20  // Blue   LED

#define GLED 13 // Green -LED
#define RLED 14 // Red   -LED
#define YLED 15 // Yellow-LED (or Orange)
#define BLED 20 // Blue  -LED
#define PLED 14 // Power -LED

#define LEDinv 0
#define BOARD "STM32F405RGT6-Pyboard"
#define board_stm32

uint8 stm32bdos(uint16 dmaaddr) {
	return(0x00);
}

#endif

// STM32CubeProgrammer software for Win64 v2.11.0